package ro.ubb.catalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogMainApplicationTests {

    @Test
    void contextLoads() {
    }

}

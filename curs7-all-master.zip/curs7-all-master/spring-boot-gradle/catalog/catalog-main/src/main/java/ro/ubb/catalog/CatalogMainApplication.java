package ro.ubb.catalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "ro.ubb.catalog")
public class CatalogMainApplication {

    public static void main(String[] args) {
        SpringApplication.run(CatalogMainApplication.class, args);
    }

}

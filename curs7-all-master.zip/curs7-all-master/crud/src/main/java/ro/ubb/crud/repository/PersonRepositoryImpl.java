package ro.ubb.crud.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import ro.ubb.crud.model.Person;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * new (transient) -> managed
 * managed -> removed | detached | 'db'
 * removed -> detached | managed | 'db'
 * 'db' -> managed
 */

@Repository
public class PersonRepositoryImpl implements PersonRepository {
    @Autowired
    private EntityManagerFactory entityManagerFactory;


    @Override
    public void save(Person person) {
        //person is in New or Transient state

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();

        entityManager.persist(person);
        //person is in Managed state

        entityTransaction.commit();
        //person is now saved in the 'db'

        entityManager.close();

    }

    @Override
    public List<Person> getPersonsByName(String name) {
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        String sql = "select p from Person p where p.name=?1";
        TypedQuery<Person> query = entityManager.createQuery(sql, Person.class);
        query.setParameter(1, name);
        List<Person> persons = query.getResultList();
        //persons are in managed state

        entityManager.close();

        return persons;
    }

    @Override
    public Person findById1(Long id) {
        System.out.println("============= findById1 =====================");

        EntityManager entityManager = entityManagerFactory.createEntityManager();

        Person person = entityManager.find(Person.class, id);
        //person is in managed state
        System.out.println("findById1 - person1:");
        System.out.println(person);

        Person person2 = entityManager.find(Person.class, id);
        System.out.println("findById1 - person2:");
        System.out.println(person2);

        entityManager.close();
        //person is now in detached state

        return person;
    }

    @Override
    public Person findById2(Long id) {
        System.out.println("============= findById2 =====================");

        EntityManager entityManager = entityManagerFactory.createEntityManager();

        Person person=entityManager.getReference(Person.class,id);
        System.out.println("findById2 - person1:");
        System.out.println(person);

        Person person2 = entityManager.getReference(Person.class, id);
        System.out.println("findById2 - person2:");
        System.out.println(person2);
        //comment souts in findById1 and findById2; observe the behavior

        entityManager.close();
        //person is now in detached state

        return person;
    }

    @Override
    public void update(Person person) {
        //person is in detached state

        System.out.println("============== update ===============");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction=entityManager.getTransaction();
        entityTransaction.begin();

        Person updatePerson = entityManager.getReference(Person.class,person.getId());
        updatePerson.setName("p2"); //updatePerson is in managed state

        entityTransaction.commit();
        //changes to Managed entities are saved in the db

        entityManager.close();
        //updatePerson is detached

    }

    @Override
    public void deleteById(Long id) {
        System.out.println("================= delete ===============");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction=entityManager.getTransaction();
        entityTransaction.begin();

        Person person=entityManager.getReference(Person.class,id);
        //person is in Managed state

        entityManager.remove(person);
        //person is in Removed state
        //calling persist() would change the state to Managed

        entityTransaction.commit();
        //person is removed from the db

        entityManager.close();
        //person is in detached state

    }

    @Override
    public void merge1(Person person) {
        //person is detached

        System.out.println("=============== merge1 ================");
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction=entityManager.getTransaction();
        entityTransaction.begin();

        person.setName("p3");

        entityManager.merge(person);
        //person is in Managed state

        entityTransaction.commit();
        //changes to Managed entities are persisted in the db

        entityManager.close();
        //person is detached

    }

    @Override
    public void merge2(Person person) {
        // person is in Transient(New) state
        System.out.println("merge2");

        EntityManager entityManager=entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction=entityManager.getTransaction();
        entityTransaction.begin();

        entityManager.merge(person);
        //person is in Managed state

        entityTransaction.commit();
        //person is saved in the db

        entityManager.close();
        //person is detached

    }
}

package ro.ubb.crud;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import ro.ubb.crud.model.Person;
import ro.ubb.crud.repository.PersonRepository;

import java.util.List;

/**
 * Created by radu.
 */
public class Main {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext("ro.ubb.crud.config");

        PersonRepository personRepository = context.getBean(
                PersonRepository.class);

        Person person = Person.builder()
                .name("p1")
                .build();
        personRepository.save(person);

        List<Person> personsByName = personRepository.getPersonsByName("p1");
        personsByName.forEach(p -> System.out.println(p));

        Person personFindById1=personRepository.findById1(personsByName.get(0).getId()); //:(((
        System.out.println("main - personFindById1 "+personFindById1);

        Person personFindById2=personRepository.findById2(personsByName.get(0).getId()); //:(((
        System.out.println("main - personFindById2 "+personFindById2);


        System.out.println("main - update");
        Person personP1 = personRepository.getPersonsByName("p1").get(0); //:(((
        personRepository.update(personP1);
        personRepository.getPersonsByName("p2")
                .forEach(person1 -> System.out.println(person1));

        System.out.println("main - delete");
        personRepository.deleteById(personP1.getId());
        personRepository.getPersonsByName("p2")
                .forEach(person1 -> System.out.println(person1));

        System.out.println("main - merge1");
        personRepository.merge1(personRepository.getPersonsByName("p1").get(0));

        System.out.println("main - merge2");
        personRepository.merge2(Person.builder()
                .name("p4")
                .build());



        System.out.println("bye");
    }
}

package ro.ubb.catalog.web.controller;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import static org.junit.Assert.fail;

/**
 * Created by radu.
 */


public class DisciplineControllerTest {
    @Before
    public void setup() throws Exception {

    }

    @Ignore
    @Test
    public void getDisciplines() throws Exception {
        fail("Not yet implemented.");
    }

}
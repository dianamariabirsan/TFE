package ro.ubb.catalog.core.repository;

/**
 * Created by radu.
 */


public class DisciplineRepositoryTest {

}